/** @type {import('next').NextConfig} */
const nextConfig = {
  // Configurações básicas
  trailingSlash: false,
  
  // Configurações experimentais
  experimental: {
    serverComponentsExternalPackages: ['@material-tailwind/react'],
    optimizePackageImports: ['@heroicons/react'],
  },
  
  // Configurações de imagem
  images: {
    unoptimized: true,
    remotePatterns: [
      {
        protocol: "https",
        hostname: "**",
      },
      {
        protocol: "http",
        hostname: "localhost",
        port: "3001",
      },
    ],
    formats: ['image/webp', 'image/avif'],
  },
  
  // Configurações de TypeScript
  typescript: {
    ignoreBuildErrors: true,
  },
  
  // Configurações de ESLint
  eslint: {
    ignoreDuringBuilds: true,
  },
  
  // Configurações de compressão
  compress: false,
  
  // Configurações de otimização
  swcMinify: false,
  
  // Configurações de produção
  poweredByHeader: false,
  
  // Configurações de build
  output: 'standalone',
  
  // Configurações de página
  pageExtensions: ['tsx', 'ts', 'jsx', 'js'],
  
  // Configurações de diretório
  distDir: '.next',
  
  // Configurações de asset
  assetPrefix: '',
  
  // Configurações de base path
  basePath: '',
  
  // Configurações de segurança - modificadas para resolver erro 403
  async headers() {
    return [
      {
        source: '/(.*)',
        headers: [
          {
            key: 'X-Content-Type-Options',
            value: 'nosniff',
          },
          {
            key: 'Referrer-Policy',
            value: 'origin-when-cross-origin',
          },
        ],
      },
    ];
  },
  
  // Configurações de webpack
  webpack: (config, { buildId, dev, isServer, defaultLoaders, webpack }) => {
    // Configurações específicas para evitar problemas de build
    config.resolve.fallback = {
      ...config.resolve.fallback,
      fs: false,
      net: false,
      tls: false,
    };
    
    return config;
  },
};

module.exports = nextConfig;
